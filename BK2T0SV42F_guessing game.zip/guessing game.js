let gameResult = document.getElementById("gameResult");
let userInput = document.getElementById("userInput");
let randomNumber = Math.ceil(Math.random() * 100);
console.log(randomNumber)

function checkGuess() {
    let userinput = parseInt(userInput.value);
    if (userinput > randomNumber) {
        gameResult.textContent = "To high, try again...."
        gameResult.style.backgroundColor = "#1e217c"
    } else if (userinput < randomNumber) {
        gameResult.textContent = "To low, try again...."
        gameResult.style.backgroundColor = "#1e217c"
    } else if (userinput === randomNumber) {
        gameResult.textContent = "Congratulation..you got it right!!!"
        gameResult.style.backgroundColor = "green"
    } else {
        gameResult.textContent = "please provide a valid Input"
        gameResult.style.backgroundColor = "red"
    }

}